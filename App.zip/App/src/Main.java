public class Main {
    public static void main(String[] args) {
        Matematica mat = new Matematica();
        System.out.println(mat.resultado(10,4,10));
    }
}